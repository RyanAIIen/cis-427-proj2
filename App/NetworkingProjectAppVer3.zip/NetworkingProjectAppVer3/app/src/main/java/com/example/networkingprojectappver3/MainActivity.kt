package com.example.networkingprojectappver3

import android.net.http.UrlRequest.Status
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var statusApp: TextView
    lateinit var clientIdApp: EditText
    lateinit var passwordApp: EditText
    lateinit var clientIdForTempPasswordApp: EditText
    lateinit var permPasswordApp: EditText
    lateinit var status: String
    lateinit var clientId: String
    lateinit var password: String
    lateinit var clientIdForTempPassword: String
    lateinit var permPassword: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusApp  = findViewById(R.id.Status)
        statusApp.text = "No Connection"
    }

    fun updateStatus(view: View) {
        statusApp.text = "Unlock clicked"
    }

    fun unlock(view: View) {
        clientIdApp = findViewById(R.id.clientId)
        clientId = clientIdApp.text.toString()
        passwordApp = findViewById(R.id.password)
        password = passwordApp.text.toString()

    }
    fun lock(view: View) {
        clientIdApp = findViewById(R.id.clientId)
        clientId = clientIdApp.text.toString()
        passwordApp = findViewById(R.id.password)
        password = passwordApp.text.toString()

    }
    fun actTempPass(view: View) {
        clientIdForTempPasswordApp = findViewById(R.id.clientIdForTemp)
        clientIdForTempPassword = clientIdForTempPasswordApp.text.toString()
        permPasswordApp = findViewById(R.id.permPassword)
        password = permPasswordApp.text.toString()

    }

}

/*
        clientIdApp = findViewById(R.id.clientId)
        clientId = clientIdApp.text.toString()


*/